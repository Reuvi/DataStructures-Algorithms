package apps;

import adts.ArrayQueue;

public class ArrayQPlay {

	public static void main(String[] args) {
		
		ArrayQueue<String> myQ = new ArrayQueue();
		myQ.enqueue("Mets");
		myQ.enqueue("Nationals");
		myQ.enqueue("Phillies");
		myQ.enqueue("Braves");
		myQ.enqueue("Marlins");
		System.out.println(myQ);
		
		/* */
		System.out.println(myQ.isEmpty() ? "myQ is empty" : "myQ is not empty");
		System.out.println(myQ.isFull()  ? "myQ is full"  : "myQ is not full");
		System.out.println(myQ.dequeue());  // explicitly test dequeue return value
		myQ.dequeue();
		myQ.dequeue();
		myQ.dequeue();
		myQ.dequeue();
		System.out.println(myQ);
		System.out.println(myQ.isEmpty() ? "myQ is empty" : "myQ is not empty");
		System.out.println(myQ.isFull()  ? "myQ is full"  : "myQ is not full");
		
		
		ArrayQueue<Integer> myIntQ = new ArrayQueue<>();
		
		for (int i = 0; i < 10; i++) {
			if (i % 2 == 1) {
				myIntQ.enqueue(i);
			}
		}
		System.out.println(myIntQ);
		
		while (!myIntQ.isEmpty()) {
			myIntQ.dequeue();
		}
		System.out.println(myIntQ);
		System.out.println(myIntQ.isEmpty() ? "It's empty now!" : "How did I get here?");
		/**/
		
		//Testing Overloads
		ArrayQueue<String> myQ2 = new ArrayQueue();
		myQ2.enqueue("Mets");
		myQ2.enqueue("Nationals");
		myQ2.enqueue("Phillies");
		myQ2.enqueue("Braves");
		myQ2.enqueue("Marlins");
		System.out.println(myQ2);
		myQ2.enqueue("Eagles");
		System.out.println(myQ2);
		myQ2.enqueue("Test2");
		System.out.println(myQ2);
		System.out.println(myQ2.dequeue());
		System.out.println(myQ2);
		myQ2.enqueue("Marlins");
		System.out.println(myQ2);
	}

}
