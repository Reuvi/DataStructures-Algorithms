package adts;

import interfaces.QueueInterface;
import java.util.ArrayList;

public class ALQueue<E> implements QueueInterface<E> {
    private ArrayList<E> queue;

    public ALQueue() {
        queue = new ArrayList<>();
    }

    @Override
    public void enqueue(E element) {
        queue.add(element); 
    }

    @Override
    public E dequeue() {
        return queue.remove(0); 
    }

    @Override
    public boolean isEmpty() {
    	//ArrayList Method
        return queue.isEmpty();
    }

    @Override
    public boolean isFull() {
        // Since an ArrayList dynamically resizes, it's not truly "full".
        return false;
    }

    public String toString() {
		StringBuilder qStr = new StringBuilder("\nqueue: ");
		for (int i = 0; i < queue.size(); i++) {
			qStr.append(queue.get(i) + " ");
		}
		return qStr.toString();
	}
}
