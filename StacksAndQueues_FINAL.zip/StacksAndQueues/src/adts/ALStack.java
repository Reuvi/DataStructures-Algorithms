package adts;

import interfaces.StackInterface;
import java.util.ArrayList;

public class ALStack<E> implements StackInterface<E> {
    private ArrayList<E> stack;

    public ALStack() {
        stack = new ArrayList<>();
    }

    @Override
    public void push(E element) {
        stack.add(element);
    }

    @Override
    public E pop() {
        return stack.remove(stack.size() - 1); 
    }

    @Override
    public E peek() {
        return stack.get(stack.size() - 1); 
    }

    @Override
    public boolean isEmpty() {
        return stack.isEmpty();
    }

    @Override
    public boolean isFull() {
        // Since an ArrayList dynamically resizes, it's not truly "full".
        return false;
    }

    public String toString() {
		StringBuilder qStr = new StringBuilder("\nstack: \n");
		for (int i = stack.size() - 1; i >= 0; i--) {
			qStr.append(stack.get(i) + "\n");
		}
		return qStr.toString();
	}
}
