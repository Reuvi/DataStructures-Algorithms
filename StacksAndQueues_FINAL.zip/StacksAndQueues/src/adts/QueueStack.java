package adts;

import interfaces.StackInterface;
import adts.LLQueue;

public class QueueStack<E> implements StackInterface<E> {
    private LLQueue<E> mainQueue;
    private LLQueue<E> helperQueue;
    private int size;
    private int tempSize;

    public QueueStack() {
        mainQueue = new LLQueue<>();
        helperQueue = new LLQueue<>();
        size = 0;
    }

    @Override
    public void push(E element) {
        mainQueue.enqueue(element);
        size++;
    }

    @Override
    public E pop() {
    	tempSize = size;
        
    	// Move elements from mainQueue to helperQueue, leaving one.
        while (tempSize > 1) {
            helperQueue.enqueue(mainQueue.dequeue());
            tempSize--;
        }
        // The last element in mainQueue is the top of the stack
        E topElement = mainQueue.dequeue();
        
        // Swap the queues
        LLQueue<E> temp = mainQueue;
        mainQueue = helperQueue;
        helperQueue = temp;
        size--;
        
        return topElement;
    }

    @Override
    public E peek() {
    	tempSize = size;
        while (tempSize > 1) {
            helperQueue.enqueue(mainQueue.dequeue());
            tempSize--;
        }
        
        E topElement = mainQueue.dequeue();
        helperQueue.enqueue(topElement); // Re-enqueue the top element to helperQueue

        // Swap the queues
        LLQueue<E> temp = mainQueue;
        mainQueue = helperQueue;
        helperQueue = temp;
        
        return topElement;
    }

    @Override
    public boolean isEmpty() {
        return mainQueue.isEmpty();
    }

    @Override
    public boolean isFull() {
        return false;
    }
    
    @Override
    public String toString() {
        StringBuilder qStr = new StringBuilder("\nstack: \n");
        
        // Transfer elements from mainQueue to helperQueue to access them
        while (!mainQueue.isEmpty()) {
            E element = mainQueue.dequeue();
            helperQueue.enqueue(element);
            qStr.append(element.toString()).append("\n");
        }
        
        // Transfer elements back to mainQueue to preserve the original state
        while (!helperQueue.isEmpty()) {
            mainQueue.enqueue(helperQueue.dequeue());
        }
        
        return qStr.toString();
    }

}
