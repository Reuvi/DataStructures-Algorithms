package adts;

import interfaces.QueueInterface;
import nodes.LLNode;

public class LLQueue<E> implements QueueInterface<E> {
	
	LLNode<E> front;
	LLNode<E> rear;
	
	@Override
	public void enqueue(E element) {
		// TODO Auto-generated method stub
		LLNode<E> newNode = new LLNode<>(element);
		if (front == null) 
		{	
			front = rear = newNode;
		}
		else {
		rear.setNext(newNode);
		rear = newNode;
		}
	}	

	@Override
	public E dequeue() {
		// TODO Auto-generated method stub
		E temp = front.getData();
		front = front.getNext();
		if (front == null) {
			rear = null;
		}
		return temp;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return front == null;
	}

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		return false;
	}
	
	public String toString() {
		StringBuilder qStr = new StringBuilder("\nqueue: ");
		LLNode<E> ptr = front;
		while (ptr != null) {
			qStr.append(ptr.getData() + " ");
			ptr = ptr.getNext();
		}
		return qStr.toString();
	}

}
