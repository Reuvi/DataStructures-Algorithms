package adts;

import interfaces.QueueInterface;

public class ArrayQueue<E> implements QueueInterface<E> {

	protected E[] queue;
	protected int front = 0;
	protected int rear = -1;
	protected int Elements = 0; //Necesary to create our isEmpty and isFull
	protected final int DEFAULT_CAPACITY = 6;
	
	public ArrayQueue() {
		queue = (E[]) new Object[DEFAULT_CAPACITY];
	}
	
	public ArrayQueue(int capacity) {
		queue = (E[]) new Object[capacity];
	}
	
	@Override
	public void enqueue(E element) {
		// TODO Auto-generated method stub
		// To achieve an O(1) with the array I have to make an implentation decision here
		// Normally if we decided to Enqueue We would have an error if we overrided
		// Fortuantly this error is no longer the case but instead we "Overwrite" data when we
		// Approach the limit. This makes sense because of my circular implementation of the
		// Dequeue.
		
		
		//In the case we add past our limit the front gets deleted off the array to make room
		//For the back
		if (rear + 1 == 6) {
		front = (front + 1) % queue.length;
		}
		
		rear = (rear + 1) % queue.length; // Circular Enqueue
		
		queue[rear] = element;
		if (Elements < 6) {
		Elements++;
		}
	}

	@Override
	
	//Again I have that circular dequeue method I made here. Its essentially shifting the front of
	// the queue to the next element resetting itself as null. The null can then be circulary replaced
	//By the rear when it approaches. Unfortuantly if the array is full and we add the enqueue will over
	//write the value is front. That is the only error but I believe we should leave the error handling
	//Up to the programmers right?
	public E dequeue() {
		// TODO Auto-generated method stub
		E temp = queue[front];
		queue[front] = null;
		front = (front + 1) % queue.length; // Circular Implementation
		Elements--;
		return temp;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return Elements == 0;
	}

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		return Elements == queue.length;
	}
	
	public String toString() {
		StringBuilder qStr = new StringBuilder("\nqueue: ");
		for (int i = 0; i < Elements; i++) {
			qStr.append(queue[(front + i) % queue.length] + " "); // Circular print so it prints front to back
		}
		return qStr.toString();
	}
}
