package recursion;

import java.util.Scanner;

public class FactorialCalc {
	
	static long factorialIterative(long n) {
		long result = 1;
		while(n > 0) {
			result = result * n--;
		}
		return result;
	}

	static long factorialRecursive(long n) {
		if (n ==0 ) {
			return 1;
		}
		else {
			return n * factorialRecursive(n-1);
		}
	}

	public static void main(String[] args) {
		
	    Scanner consoleInput = new Scanner(System.in);
		
		long factorial, startTime, elaspedTime, n = 0;
		
	    do
	    {
	      System.out.println("\nEnter an integer value for factorial calculation, 0 to quit: ");
	      n = consoleInput.nextInt();
	      System.out.println();
	      startTime = System.nanoTime();
	      factorial = factorialIterative(n);
	      elaspedTime = System.nanoTime() - startTime;
	      System.out.println(n + "! = " + factorial + "  iteratively; time " + elaspedTime);
	      startTime = System.nanoTime();
	      factorial = factorialRecursive(n);
	      elaspedTime = System.nanoTime() - startTime;
	      System.out.println(n + "! = " + factorial + "  recursivley; time " + elaspedTime);
	    }
	    while (n != 0);

	}

}
