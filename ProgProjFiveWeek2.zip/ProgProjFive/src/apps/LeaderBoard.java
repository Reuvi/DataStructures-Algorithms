package apps;

import adts.BinarySearchTree;
import java.util.*;


public class LeaderBoard {
  
	public static void main(String[] args) {
		
		BinarySearchTree<Golfer> golfers = new BinarySearchTree<Golfer>();
		
		golfers.add(new Golfer("Hideki", 74));
		golfers.add(new Golfer("Cheyenne", 73));
		golfers.add(new Golfer("Matt", 77));
		golfers.add(new Golfer("Bel�n", 76));
		golfers.add(new Golfer("Brooks", 75));
		golfers.add(new Golfer("Natalie", 68));
		golfers.add(new Golfer("Xander", 71));
		golfers.add(new Golfer("Lexi", 79));
		golfers.add(new Golfer("Rory", 70));
		
		ArrayList<Golfer> golferList = new ArrayList<>();
		
		int average = 0;
		
		System.out.println("Leader Board\n-------------------");
		golfers.setTraversalType("in");
		for(Golfer x : golfers) {
			average += x.getScore();
			System.out.println(x);
			golferList.add(x);
		}
		
		System.out.println("\nAverage score: " + average / golferList.size());
		
		System.out.println("\nMedian score: " + golferList.get(golferList.size() / 2).getScore());
		
		
		
	}
}