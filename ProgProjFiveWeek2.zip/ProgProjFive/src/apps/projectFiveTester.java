package apps;

import adts.*;

public class projectFiveTester {
	
	public static void main(String[] args) {
		
		BinarySearchTree<Integer> testTree = new BinarySearchTree<>();
		
		testTree.add(3);
		testTree.add(1);
		testTree.add(4);
		testTree.add(4);
		testTree.add(7);
		testTree.add(2);
		testTree.add(2);
		testTree.add(10012);
		testTree.add(213);
		
		System.out.println(testTree.max());
		
	}
}
