package adts;

import interfaces.QueueInterface;

public class ArrayQueueFF0<E> implements QueueInterface<E> {
	
	protected E[] queue;
	protected final int FRONT = 0;
	protected int rear = -1;
	protected final int DEFAULT_CAPACITY = 6;
	
	@SuppressWarnings("unchecked")
	public ArrayQueueFF0() {
		queue = (E[]) new Object[DEFAULT_CAPACITY];
	}
	
	@SuppressWarnings("unchecked")
	public ArrayQueueFF0(int capacity) {
		queue = (E[]) new Object[capacity];
	}
	
	@Override
	public void enqueue(E element) {
		// TODO Auto-generated method stub
		queue[++rear] = element;
	}

	@Override
	public E dequeue() {
		// TODO Auto-generated method stub
		E temp = queue[FRONT];
		for(int i = FRONT; i < rear; i++) {
			queue[i] = queue[i + 1];
		}
		queue[rear] = null;
		rear--;
		return temp;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return rear == -1;
	}

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		return rear == queue.length - 1;
	}
	
	public String toString() {
		StringBuilder qStr = new StringBuilder("\nqueue: ");
		for (int i = FRONT; i <= rear; i++) {
			qStr.append(queue[i] + " ");
		}
		return qStr.toString();
	}
	

}
