package iterators;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import nodes.DLLNode;
import java.util.*;

public class RandomOrderIterator<E> implements Iterator<E> {
    private final List<E> list;
    private final Iterator<E> iterator;

    public RandomOrderIterator(DLLNode<E> head, int size) {
        this.list = new ArrayList<>(size);
        DLLNode<E> current = head;
        while (current != null) {
            list.add(current.getData());
            current = current.getNext();
        }
        Collections.shuffle(list);
        this.iterator = list.iterator();
    }

    @Override
    public boolean hasNext() {
        return iterator.hasNext();
    }

    @Override
    public E next() {
        return iterator.next();
    }
}
