package iterators;

import java.util.Iterator;
import java.util.NoSuchElementException;
import nodes.DLLNode;

public class AlternatingIterator<E> implements Iterator<E> {
    private DLLNode<E> forward;
    private DLLNode<E> backward;
    private boolean forwardTurn = true;
    private final int size;
    private int iterated = 0; // Track the number of elements iterated

    public AlternatingIterator(DLLNode<E> head, DLLNode<E> tail, int size) {
        this.forward = head;
        this.backward = tail;
        this.size = size;
    }

    @Override
    public boolean hasNext() {
        // Return true only if the number of iterated elements is less than the size of the list
        return iterated < size;
    }

    @Override
    public E next() {
        if (!hasNext()) throw new NoSuchElementException();
        
        E data = null;
        // Ensure we don't try to access data if we're beyond the list bounds
        if (forwardTurn && forward != null) {
            data = forward.getData();
            forward = (forward == backward) ? null : forward.getNext(); // Advance forward or set to null if at the middle
            iterated++;
        } else if (!forwardTurn && backward != null) {
            data = backward.getData();
            backward = (backward == forward) ? null : backward.getPrev(); // Move backward or set to null if at the middle
            iterated++;
        }
        forwardTurn = !forwardTurn; // Toggle turn
        return data;
    }
}
