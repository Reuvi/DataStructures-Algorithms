package iterators;

import java.util.Iterator;
import nodes.DLLNode;
import java.util.NoSuchElementException;

public class ReverseOrderIterator<E> implements Iterator<E> {
    private DLLNode<E> current;

    public ReverseOrderIterator(DLLNode<E> tail) {
        this.current = tail;
    }

    @Override
    public boolean hasNext() {
        return current != null;
    }

    @Override
    public E next() {
        if (!hasNext()) throw new NoSuchElementException();
        E data = current.getData();
        current = current.getPrev();
        return data;
    }
}

