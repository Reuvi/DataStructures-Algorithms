package iterators;

import java.util.Iterator;
import nodes.DLLNode;

public class InOrderIterator<E> implements Iterator<E> {
    private DLLNode<E> current;

    public InOrderIterator(DLLNode<E> head) {
        this.current = head;
    }

    @Override
    public boolean hasNext() {
        return current != null;
    }

    @Override
    public E next() {
        E data = current.getData();
        current = current.getNext();
        return data;
    }
}
