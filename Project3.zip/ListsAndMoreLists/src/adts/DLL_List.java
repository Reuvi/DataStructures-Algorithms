package adts;

import interfaces.ListInterface;
import iterators.*;
import nodes.DLLNode;
import java.util.Iterator;

public class DLL_List<E extends Comparable<E>> implements ListInterface<E>, Iterable<E> {
    private DLLNode<E> head, tail; 
    private int size;
    private IterationMode currentIterationMode = IterationMode.IN_ORDER;

    public enum IterationMode {
        IN_ORDER, REVERSE_ORDER, RANDOM_ORDER, ALTERNATING
    }

    public DLL_List() {
        head = null;
        tail = null; 
        size = 0;
    }

    @Override
    public void add(E element) {
        DLLNode<E> newNode = new DLLNode<>(element);
        if (head == null) {
            head = newNode;
            tail = newNode; 
        } else if (head.getData().compareTo(element) > 0) {
            newNode.setNext(head);
            head.setPrev(newNode);
            head = newNode;
        } else {
            DLLNode<E> current = head;
            while (current.getNext() != null && current.getNext().getData().compareTo(element) < 0) {
                current = current.getNext();
            }
            newNode.setNext(current.getNext());
            newNode.setPrev(current);
            if (current.getNext() != null) {
                current.getNext().setPrev(newNode);
            } else {
                tail = newNode; 
            }
            current.setNext(newNode);
        }
        size++;
    }

    @Override
    public boolean remove(E element) {
        DLLNode<E> current = head;
        while (current != null) {
            if (current.getData().equals(element)) {
                if (current.getPrev() != null) {
                    current.getPrev().setNext(current.getNext());
                } else {
                    head = current.getNext(); 
                }
                if (current.getNext() != null) {
                    current.getNext().setPrev(current.getPrev());
                } else {
                    tail = current.getPrev(); 
                }
                size--;
                return true;
            }
            current = current.getNext();
        }
        return false;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public boolean contains(E element) {
        return find(element) != null;
    }

    @Override
    public E get(E element) {
        DLLNode<E> node = find(element);
        return node == null ? null : node.getData();
    }

    @Override
    public E get(int index) {
        if (index < 0 || index >= size) {
            return null;
        }
        DLLNode<E> current = head;
        for (int i = 0; i < index; i++) {
            current = current.getNext();
        }
        return current.getData();
    }

    public DLLNode<E> find(E element) {
        boolean found = false;
        DLLNode<E> result = null;
        
        int first = 0;
        int last = size - 1;
        while (first <= last) {
            int mid = first + (last - first) / 2;
            DLLNode<E> midNode = getNodeAt(mid);
            
            if (midNode.getData().equals(element)) {
                found = true;
                result = midNode;
                break;
            } else if (element.compareTo(midNode.getData()) < 0) {
                last = mid - 1;
            } else {
                first = mid + 1;
            }
        }
        
        if (found) {
            return result;
        } else {
            return null; // Or any indication that the element was not found
        }
    }
    
    // Helper method to "simulate" indexed access by traversing the list
    private DLLNode<E> getNodeAt(int index) {
        if (index < 0 || index >= size) {
            return null;
        }
        DLLNode<E> current = head;
        for (int i = 0; i < index; i++) {
            current = current.getNext();
        }
        return current;
    }
    

    @Override
    public Iterator<E> iterator() {
        return getIterator(currentIterationMode);
    }

    public void setCurrentIterationMode(IterationMode mode) {
        this.currentIterationMode = mode;
    }

    
    public Iterator<E> getIterator(IterationMode mode) {
        switch (mode) {
            case IN_ORDER:
                return new InOrderIterator<>(head);
            case REVERSE_ORDER:
                return new ReverseOrderIterator<>(tail);
            case RANDOM_ORDER:
                return new RandomOrderIterator<>(head, size);
            case ALTERNATING:
                return new AlternatingIterator<>(head, tail, size);
            default:
                throw new IllegalArgumentException("Invalid iteration mode");
        }
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        DLLNode<E> current = head;
        sb.append("[");
        while (current != null) {
            sb.append(current.getData().toString());
            if (current.getNext() != null) {
                sb.append(", ");
            }
            current = current.getNext();
        }
        sb.append("]");
        return sb.toString();
    }

}
