package apps;

import adts.DLL_List;
import adts.DLL_List.IterationMode;

public class PlayWithDLL {

	public static void main(String[] args) {
		DLL_List<String> animals = new DLL_List<String>();
		animals.add("Dog");
		animals.add("Cat");
		animals.add("Moose");
		animals.add("Hippo");
		System.out.println(animals);
		System.out.println("Remove Hippo: " + animals.remove("Hippo"));
		System.out.println(animals);
		System.out.println("Get moose: " + animals.get("Moose"));
		System.out.println(animals.size() + " Remove first item Dog: " + animals.remove("Dog"));
		System.out.println(animals);
		System.out.println(animals.size() + " Remove last item Moose: " + animals.remove("Moose"));
		System.out.println(animals);
		animals.add("Horse");
		animals.add("Cow");
		animals.add("Sheep");
		animals.add("Pig");
		animals.add("Donkey");
		animals.add("Chicken");
		System.out.println(animals);
		System.out.println("Get item at index 0 (Cat): " + animals.get(0));
		System.out.println("Get item at index 2 (Cow): " + animals.get(2));
		System.out.println("Get item at index 3 (Sheep): " + animals.get(3));
		System.out.println("Remove Cow: " + animals.remove("Cow"));
		System.out.println(animals + "\n\n---------------\n");
		
		// Print in order
        System.out.println("Print in order:");
        animals.setCurrentIterationMode(IterationMode.IN_ORDER);
        for (String element : animals) {
            System.out.println(element);
        }

        // Print in reverse order
        System.out.println("\nPrint in reverse order:");
        animals.setCurrentIterationMode(IterationMode.REVERSE_ORDER);
        for (String element : animals) {
            System.out.println(element);
        }

        // Print by random order
        System.out.println("\nPrint by random:");
        animals.setCurrentIterationMode(IterationMode.RANDOM_ORDER);
        for (String element : animals) {
            System.out.println(element);
        }

        // Print by alternating order
        System.out.println("\nPrint by alternating:");
        animals.setCurrentIterationMode(IterationMode.ALTERNATING);
        for (String element : animals) {
            System.out.println(element);
        }
	}

}
