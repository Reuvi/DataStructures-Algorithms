package adts;

import interfaces.ListInterface;

public class ArraySortedList<E> extends ArrayBasedList<E> implements ListInterface<E> {

	public ArraySortedList() {
		super();
	}
	
	public ArraySortedList(int initialCapacity) {
		super(initialCapacity);
	}
	
	@Override
	//Maintain Insertion Order
	public boolean remove(E element) {
		find(element);
		if(found) {
			for (int i = location; i < numElements -1; i++) {
				list[i] = list[i + 1];
			}
			list[numElements - 1] = null;
			numElements--;
		}
		return found;
	}
	
	public void add(E element) {
		if (numElements == list.length) {
			E[] tempArray = (E[]) new Object[list.length + initialCapacity];
			for(int i = 0; i < list.length; i++) {
				tempArray[i] = list[i];
			}
			list = tempArray;
		}        
		
		int addLocation = 0;
		
		while(addLocation < numElements) {
			if ( ((Comparable) element).compareTo(list[addLocation]) > 0 ) {
				addLocation++;
			}
			else {
				break;
			}
		}
		
		for(int i = numElements; i > addLocation; i--) {
			list[i] = list[i - 1];
		}
		list[addLocation] = element;
		numElements++;
		}
	
	public void find(E element) {
		
		found = false;
		location = 0;
		int first = 0;
		int last = numElements - 1;
		while(true) {
			//int mid =(first + last) /2;
			int mid = first + (last - first)/2; //Integer Overflow Protection
			
			if(list[mid].equals(element)) {
				location = mid;
				found = true;
				break;
			}
			else if ( ((Comparable) element).compareTo(list[mid]) < 0) {
				last = mid - 1;
			}
			else {
				first = mid + 1;
			}
			
			if(first > last) {
				found = false;
				break;
			}
		}
	}
	
}
