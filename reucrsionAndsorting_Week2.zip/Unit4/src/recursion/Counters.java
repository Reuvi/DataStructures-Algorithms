package recursion;

import java.util.Scanner;

public class Counters {
	
	public static int spaceCountIterative(String phrase)  {
		int count = 0;
		for(int i = 0; i < phrase.length(); i++) {
			if (" ".indexOf((phrase.substring(i)).charAt(0)) >= 0) {
				count = 1 + count;
			}
		}
		return count + 1;
	}
	
	public static int spaceCountRecursive(String phrase)  {
		if(phrase.length() == 0) {
			return 1;
		}
		else {
			if (" ".indexOf(phrase.charAt(0)) >= 0) {
				return 1 + spaceCountRecursive(phrase.substring(1));
			}
			else {
				return spaceCountRecursive(phrase.substring(1));
			}
		}
	}
		

	
	// counting spaces as a proxy for the number of words
	
	// if (" ".indexOf((phrase.substring(i)).charAt(0)) >= 0) {  
	// to count spaces
	
	// if ("aeiouAEIOU".indexOf((phrase.substring(i)).charAt(0)) >= 0) {  
	// to count vowels
	
	public static void main(String[] args) 	{
		
		Scanner input = new Scanner(System.in);
		
		int count;
		
		String phrase;
		
		System.out.println("Please input a phrase that you would liked checked, or type 'quit' to end");
		phrase = input.nextLine();
		
		while (!phrase.equals("quit")) {
			
			count = spaceCountIterative(phrase);
			System.out.println("Iterative >>> word count: " + count);
			
			count = spaceCountRecursive(phrase);
			System.out.println("Recursive >>> word count: " + count);
			
			System.out.println("Please input a phrase that you would like checked, or type 'quit' to end");
			phrase = input.nextLine();
		}
		
		System.out.println("That's All Folks!");

		input.close();
		
	}
}
