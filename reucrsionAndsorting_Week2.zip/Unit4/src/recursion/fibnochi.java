package recursion;




public class fibnochi {
	
	public static int fibonochi(int x) {
		if(x <= 2) {
			return 1;
		}
		else {
			return fibonochi(x - 1) + fibonochi(x - 2);
			
		} 
	}
	
	public static void main(String[] args) {
		int answer = fibonochi(20);
		System.out.println(answer);
	}
}
