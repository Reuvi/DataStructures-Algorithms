package recursion;

import java.util.*;

public class mathPow {
	
	
	//Recursive Power
	public static int pow(int r, int n) {
		/*Base case if n == 0 we return 1
		 	Otherwise we multiply by r n times
		 */
		if (n == 0) {
			return 1;
		}
		else if (r == 1) {
			return 1;
		}
		else if (r == 0) {
			return 0;
		}
		else {
			return r * pow(r, n-1);
		}
	}
	
	public static void main(String[] args) {
		
		ArrayList<Integer> powers = new ArrayList<>();
		
		int n = 1;
		for(int i = 0; i < 1000000; i++) {
			n *= 1;
			powers.add(n);
			System.out.println(n);
			
		}
		
		System.out.println(" ____________DONE______________");
		System.out.println(powers.size());
	}
}
