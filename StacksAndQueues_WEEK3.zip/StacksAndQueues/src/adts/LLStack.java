package adts;

import interfaces.StackInterface;

import nodes.LLNode;

public class LLStack<E> implements StackInterface<E> {
	
	protected LLNode<E> top; // Reference to the head
	
	@Override
	public void push(E element) {
		// TODO Auto-generated method stub
		LLNode<E> newNode = new LLNode<>(element);
		newNode.setNext(top);
		top = newNode;
	}

	@Override
	public E pop() {
		// TODO Auto-generated method stub
		E temp = top.getData();
		top = top.getNext();
		return temp;
	}

	@Override
	public E peek() {
		// TODO Auto-generated method stub
		return top.getData();
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return top == null;
	}

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		return false;
	}
	
	public String toString() {
		StringBuilder qStr = new StringBuilder("\nStack(Top to Bottom): ");
		LLNode<E> ptr = top;
		while (ptr != null) {
			qStr.append(ptr.getData() + "/n");
			ptr = ptr.getNext();
		}
		return qStr.toString();
	}

}
