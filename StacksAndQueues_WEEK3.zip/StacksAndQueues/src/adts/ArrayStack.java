package adts;

import interfaces.StackInterface;

public class ArrayStack<E> implements StackInterface<E> {
	
	protected E[] stack;
	protected int top = -1;
	protected final int DEFAULT_CAPACITY = 6;
	
	@SuppressWarnings("unchecked")
	public ArrayStack() {
		stack = (E[]) new Object[DEFAULT_CAPACITY];
	}
	
	@SuppressWarnings("unchecked")
	public ArrayStack(int capacity) {
		stack = (E[]) new Object[capacity];
	}
	
	
	
	@Override
	public void push(E element) {
		// TODO Auto-generated method stub
		
		/*for(int i = stack.length -1; i > 0; i--){
			stack[i] = stack[i - 1];
		}
		stack[FRONT] = element; */
		
		top += 1;
		stack[top] = element;
	}

	@Override
	public E pop() {
		// TODO Auto-generated method stub
		/*E temp = stack[FRONT];
		for(int i = 0; i < stack.length - 1; i++) {
			stack[i] = stack[i + 1]; 
		}
		return temp;*/
		
		E temp = stack[top];
		top -= 1;
		return temp;
	}

	@Override
	public E peek() {
		// TODO Auto-generated method stub
		return stack[top];
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return top == -1;
	}

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		return top == stack.length -1;
	}
	
	public String toString() {
		StringBuilder qStr = new StringBuilder("\nstack: \n");
		for (int i = top; i >= 0; i--) {
			qStr.append(stack[i] + "\n");
		}
		return qStr.toString();
	}

}
